import smtplib

my_email = "sender@gmail.com"
password = "12345678"

connection = smtplib.SMTP("smtp.gmail.com",587)
connection.starttls()
connection.login(user=my_email, password=password)
connection.sendmail(from_addr=my_email,to_addrs="receiver@gmail.com", msg="Hello World")
connection.close()